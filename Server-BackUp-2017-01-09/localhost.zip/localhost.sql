-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2017-01-09 12:55:29
-- 服务器版本： 5.7.16-0ubuntu0.16.04.1
-- PHP Version: 7.0.8-0ubuntu0.16.04.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `AutoWaterSystem`
--
DROP DATABASE `AutoWaterSystem`;
CREATE DATABASE IF NOT EXISTS `AutoWaterSystem` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `AutoWaterSystem`;

-- --------------------------------------------------------

--
-- 表的结构 `capture_info`
--

CREATE TABLE IF NOT EXISTS `capture_info` (
  `capture_num` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '捕获的顺序编号，从1开始自增编号',
  `sensor_id` int(11) UNSIGNED NOT NULL COMMENT '传感器的编号，和sensor_info表对应',
  `sensor_capture` varchar(255) NOT NULL COMMENT '传感器捕获的图片文件名，默认为空，按照上传时间“sensor_id-YYYYMMdd-hhmmss-ms.jpg”格式存储到存储空间',
  PRIMARY KEY (`capture_num`),
  UNIQUE KEY `capture_num` (`capture_num`),
  KEY `sensor_id` (`sensor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 表的关联 `capture_info`:
--   `sensor_id`
--       `sensor_info` -> `sensor_id`
--

--
-- 插入之前先把表清空（truncate） `capture_info`
--

TRUNCATE TABLE `capture_info`;
--
-- 转存表中的数据 `capture_info`
--

INSERT INTO `capture_info` (`capture_num`, `sensor_id`, `sensor_capture`) VALUES
(1, 200000000, 'NULL.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `sensor_info`
--

CREATE TABLE IF NOT EXISTS `sensor_info` (
  `sensor_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '传感器编号，自增，从20000000000开始',
  `user_id` int(11) UNSIGNED NOT NULL COMMENT '传感器所属的用户ID',
  `sensor_type` int(4) UNSIGNED NOT NULL DEFAULT '0' COMMENT '传感器类型，1表示数值型，2表示开关型，3表示图像型',
  `sensor_value` int(5) NOT NULL DEFAULT '0' COMMENT '传感器数值，默认0，只针对1-数值型',
  `sensor_status` int(1) UNSIGNED NOT NULL DEFAULT '0' COMMENT '传感器状态，默认0，只针对2-开关型，1表示开',
  `sensor_capture` varchar(255) DEFAULT NULL COMMENT '传感器捕获的图片文件名，默认为空，按照上传时间“sensor_id-YYYYMMdd-hhmmss-ms.jpg”格式存储到存储空间',
  PRIMARY KEY (`sensor_id`),
  UNIQUE KEY `sensor_id` (`sensor_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=200000002 DEFAULT CHARSET=utf8 COMMENT='传感器信息定义表';

--
-- 表的关联 `sensor_info`:
--   `user_id`
--       `user_info` -> `user_id`
--

--
-- 插入之前先把表清空（truncate） `sensor_info`
--

TRUNCATE TABLE `sensor_info`;
--
-- 转存表中的数据 `sensor_info`
--

INSERT INTO `sensor_info` (`sensor_id`, `user_id`, `sensor_type`, `sensor_value`, `sensor_status`, `sensor_capture`) VALUES
(200000000, 100000000, 0, 55, 0, NULL),
(200000001, 100000000, 2, 233, 0, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `sensor_log`
--

CREATE TABLE IF NOT EXISTS `sensor_log` (
  `log_num` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '顺序编号，从1开始',
  `sensor_id` int(11) UNSIGNED NOT NULL COMMENT '传感器编号，不为空，外键',
  `sensor_value` int(1) UNSIGNED NOT NULL COMMENT '传感器数值，数值型与开关型统一记录',
  `log_datetime` datetime NOT NULL COMMENT '传感器数据上传日期时间',
  PRIMARY KEY (`log_num`),
  KEY `sensor_id` (`sensor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='传感器数据历史记录表';

--
-- 表的关联 `sensor_log`:
--   `sensor_id`
--       `sensor_info` -> `sensor_id`
--

--
-- 插入之前先把表清空（truncate） `sensor_log`
--

TRUNCATE TABLE `sensor_log`;
--
-- 转存表中的数据 `sensor_log`
--

INSERT INTO `sensor_log` (`log_num`, `sensor_id`, `sensor_value`, `log_datetime`) VALUES
(1, 200000000, 0, '2017-01-07 21:17:07'),
(2, 200000000, 233, '2017-01-07 21:28:34'),
(8, 200000000, 333, '2017-01-08 13:39:36'),
(9, 200000000, 33355, '2017-01-08 13:50:11'),
(10, 200000000, 55, '2017-01-08 15:56:27'),
(11, 200000001, 55, '2017-01-08 15:57:31'),
(12, 200000001, 233, '2017-01-08 15:58:42'),
(13, 200000001, 0, '2017-01-08 16:06:11');

-- --------------------------------------------------------

--
-- 表的结构 `user_info`
--

CREATE TABLE IF NOT EXISTS `user_info` (
  `user_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '用户的ID标识，自增，从10000000000开始',
  `user_name` varchar(50) NOT NULL COMMENT '用户名',
  `user_pass` varchar(255) NOT NULL COMMENT '加密后的密文',
  `user_regdate` datetime NOT NULL COMMENT '用户的注册时间，用于和用户名生成盐',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `user_pass` (`user_pass`),
  KEY `user_pass_2` (`user_pass`)
) ENGINE=InnoDB AUTO_INCREMENT=100000001 DEFAULT CHARSET=utf8 COMMENT='用户信息存储表，用于身份验证';

--
-- 表的关联 `user_info`:
--

--
-- 插入之前先把表清空（truncate） `user_info`
--

TRUNCATE TABLE `user_info`;
--
-- 转存表中的数据 `user_info`
--

INSERT INTO `user_info` (`user_id`, `user_name`, `user_pass`, `user_regdate`) VALUES
(100000000, 'xuxinting', '04b0590aa1ee6f812bad24e7c1628c1dee84abff', '2017-01-07 21:17:07');

--
-- 限制导出的表
--

--
-- 限制表 `capture_info`
--
ALTER TABLE `capture_info`
  ADD CONSTRAINT `sensor_constrain` FOREIGN KEY (`sensor_id`) REFERENCES `sensor_info` (`sensor_id`);

--
-- 限制表 `sensor_info`
--
ALTER TABLE `sensor_info`
  ADD CONSTRAINT `user_constrains` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `sensor_log`
--
ALTER TABLE `sensor_log`
  ADD CONSTRAINT `sensor_id` FOREIGN KEY (`sensor_id`) REFERENCES `sensor_info` (`sensor_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
